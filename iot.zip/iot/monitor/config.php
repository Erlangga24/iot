<?php
$host   = "riset.revolusi-it.com"; 
$port     = 1883;
$username = "usm";
$password = "rahasia234";

?>
